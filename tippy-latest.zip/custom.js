
// Initialize Tippy.js
tippy('.tooltip', {
    content(reference) {
        return reference.getAttribute('data-tippy-content');
    },
    allowHTML: true,
    theme: 'light-border',
    maxWidth: 500, // You can adjust the maximum width
    interactive: true,
    arrow: false // This line hides the arrow
});

document.addEventListener("DOMContentLoaded", function() {
    // Select all anchor tags
    var anchorTags = document.querySelectorAll("a");
    
    // Iterate over each anchor tag and remove the style attribute
    anchorTags.forEach(function(anchor) {
        anchor.removeAttribute("style");
    });
});